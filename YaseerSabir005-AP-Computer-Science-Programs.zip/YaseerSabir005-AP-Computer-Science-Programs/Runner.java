package Assignments;

public class Runner {

	public static void main(String[] args) {

		Cat obj = new Cat("Ellie", 5);// at 5 days
		System.out.println(obj);

		System.out.println();

		Cat obj2 = new Cat("James", 12);// at 12 days
		System.out.println(obj2);

		System.out.println();

		Kitten obj3 = new Kitten("Nikko", 4);// at 4 days
		System.out.println(obj3);

		System.out.println();

		Kitten obj4 = new Kitten("Little Spot", 11);// at 4 days
		System.out.println(obj4);
		
		System.out.println();
		
		Dog obj5 = new Dog("Rocky");
		System.out.println(obj5);

	}

}
