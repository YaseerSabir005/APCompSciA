
public class RunSquare {

	public static void main(String[] args) {
		Square s = new Square(5, 6, 9);
		System.out.println(s.getArea());// 81
		System.out.println(s.getPerimeter());// 36

	}

}
